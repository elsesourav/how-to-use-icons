# how-to-use-icons

step 1: download the 'sb_icons.zip' file

step 2: extract  the file

step 3: paste the icons folder in your project root directory 

setp 4: open the demo.html as a edit mode and copy the link tag

setp 5: paste in your html page

--------- thats it (done) -----------
