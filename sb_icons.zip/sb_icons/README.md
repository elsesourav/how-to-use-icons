# how to use icons

step 1: download the **sb_icons.zip** file

step 2: extract the file

step 3: copy the **icons foldeer**

step 4: paste the folder in your project root directory 

setp 5:  copy this link tag ---> **< link rel="stylesheet" href="./icons/css/icon.css">**

setp 6: paste the tag in your html head tag

--------- thats it (done) -----------
